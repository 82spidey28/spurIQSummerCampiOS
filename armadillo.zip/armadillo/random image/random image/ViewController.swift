//
//  ViewController.swift
//  random image
//
//  Created by Spur IQ on 6/18/19.
//  Copyright © 2019 armadillo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var images = ["Bear", "Book", "Pikachu", "Eevee", "Psyduck","Rubix", "Robot"]

    @IBOutlet weak var imageView1: UIImageView!
    
    @IBOutlet weak var imageView2: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func RandomButtonClicked(_ sender: Any){
        print("Here in button click")
        let num1 = Int.random(in: 0...6)
        let num2 = Int.random(in: 0...6)

        imageView1.image = UIImage(named: images[num1])
        imageView2.image = UIImage(named: images[num2])
    
    }
}
