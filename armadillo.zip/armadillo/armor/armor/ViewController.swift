//
//  ViewController.swift
//  armor
//
//  Created by Spur IQ on 6/19/19.
//  Copyright © 2019 armadillo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView2: UIImageView!
    @IBOutlet weak var imageView1: UIImageView!
    @IBOutlet weak var imageView3: UIImageView!
    @IBOutlet weak var imageView4: UIImageView!
    /*
    var leatherImages = ["LeatherBoots", "LeatherHelmet", "LeatherChestPlate", "LeatherLeggings"]
    var emeraldImages = ["EmeraldBoots", "EmeraldHelmet", "EmeraldChestPlate", "EmeraldLeggings"]
    var ironImages = ["IronBoots", "IronHelmet", "IronChestPlate", "IronLeggings"]
    var goldImages = ["GoldBoots", "GoldHelmet", "GoldChestPlate", "GoldLeggings"]
    var diamondImages = ["DiamondBoots", "DiamondHelmet", "DiamondPlate", "DiamondLeggings"]
    */
    var bootImages = ["LeatherBoots", "IronBoots1", "EmeraldBoots", "GoldBoots", "DiamondBoots"]
    var helmetImages = ["LeatherHelmet", "IronHelmet", "EmeraldHelmet", "GoldenHelmet", "DiamondHelmet"]
    var chestPlateImages = ["LeatherChestPlate", "IronChestPlate", "EmeraldChestPlate", "GoldenChestPlate", "DiamondChestPlate"]
    var leggingsImages = ["LeatherLeggings", "IronLeggings","EmeraldLeggings",  "GoldLeggings", "DiamondLeggings"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let num1 = Int.random(in: 0...4)
        let num2 = Int.random(in: 0...4)
        let num3 = Int.random(in: 0...4)
        let num4 = Int.random(in: 0...4)
        imageView1.image = UIImage(named: helmetImages[num1])
        imageView2.image = UIImage(named: chestPlateImages[num2])
        imageView3.image = UIImage(named: leggingsImages[num3])
        imageView4.image = UIImage(named: bootImages[num4])

        // Do any additional setup after loading the view.
    }

    @IBAction func buttonClick(_ sender: Any) {
        let num1 = Int.random(in: 0...4)
        let num2 = Int.random(in: 0...4)
        let num3 = Int.random(in: 0...4)
        let num4 = Int.random(in: 0...4)
        imageView1.image = UIImage(named: helmetImages[num1])
        imageView2.image = UIImage(named: chestPlateImages[num2])
        imageView3.image = UIImage(named: leggingsImages[num3])
        imageView4.image = UIImage(named: bootImages[num4])
    }
    
    
}

