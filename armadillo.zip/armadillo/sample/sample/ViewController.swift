//
//  ViewController.swift
//  sample
//
//  Created by Spur IQ on 6/17/19.
//  Copyright © 2019 armadillo. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var toys: [String] = []
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return toys.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell1 = UITableViewCell(style: .default, reuseIdentifier: "cellID")
        cell1.textLabel!.text = toys[indexPath.row]
        return cell1
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if(editingStyle == .delete){
            toys.remove(at: indexPath.row)
            writeArrayToFile()
            tableView.reloadData()
        }
    }
    
    @IBAction func buttonClick(_ sender: Any) {
        if(textField.text != "") {
            toys.append(textField.text!)
            writeArrayToFile()
            tableView.reloadData()
            textField.text = ""
        }
    }
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var tableView: UITableView!
 
    
        override func viewDidLoad() {
        super.viewDidLoad()
         readDataFromFile()
        // Do any additional setup after loading the view.
    }


    let strFileName="spurIQArrayTest23.txt"
    let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first

    func readDataFromFile() {
        let fileURL = dir?.appendingPathComponent(strFileName)
        let fileManager = FileManager.default
        let pathComponent = dir!.appendingPathComponent(strFileName)
        let filePath = pathComponent.path
    
        if fileManager.fileExists(atPath:filePath){
            toys = NSMutableArray(contentsOf: fileURL!) as! [String]
        }
        else
        {
            writeArrayToFile()
        }
    }
    
    func writeArrayToFile()
    {
        let fileURL = dir?.appendingPathComponent(strFileName)
        (toys as NSArray).write(to: fileURL!, atomically: true)
}

}

