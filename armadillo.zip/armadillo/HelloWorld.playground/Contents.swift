import UIKit

var str = "Hello, playground"
print(str)

print("Hello World!!")

var Armadillo = "Spidey"
print("My name is \(Armadillo).")

var Spidey = "Suhaas"
print("My name is \(Spidey).")

var Suhaas = "Armadillo"
print("My name is \(Suhaas).")

var Warriors_Score = 110
var Raptors_Score = 114

if (Warriors_Score > Raptors_Score){
    print ("Warriors Won!!!")

} else {
    print ("Raptors Won!!!")
}



print("During the last game, the Warriors'score was \(Warriors_Score).")

let pi = 3.14


var r = 30.2
var area = pi*r*r
var circumference = 2*pi*r

 
 var square = pow(6,2)
 print(square)

var int1 = 10
var int2 = 20

print (int1 == int2)
print (int1 != int2)

func PrintGivenInput(name : String){
    print("My name is \(name)")
    PrintGivenInput(name:"Armadillo")
    
}
func buyStuff(stuff : String){
    print("Go to Starbucks")
    print("Find a bunch of money")
    print("Buy a parent")
    print("Newly bought parent drives you to GameStop")
    print("Find the Nintendo Switch")
    print("Throw it at the people over there")
    print("destroy everything but the Nintendo Switch")
    print("Take the money and the switch")
    print("Buy a new house with your new lottery")
    print("Throw away your newly bought parent")
    print("Play with your new Nintendo Switch")

}
buyStuff(stuff:"Nintendo Switch")
buyStuff(stuff:"game for the switch")

func multiply(num1: Int, num2 : Int) -> Int{
    return (num1 * num2)
}


func multiplyReturn(num1: Int, num2: Int){
print(num1 * num2)

}

multiplyReturn(num1: 5, num2: 3)
multiplyReturn(num1: 7, num2: 9)

print (multiply(num1: 5, num2 : 3))

if (multiply (num1 :5, num2:3)) > 100 {
}


var subjects = ["math","science","history","P.E.","speech","spelling","grammar","art"]
func AddToSubjects(sub : String){
subjects.append(sub)
}

func RemoveLast(){
subjects.removeLast()

}


print(subjects)
AddToSubjects(sub: "Economics")
print(subjects)
RemoveLast()
print(subjects)
subjects.remove(at:2)
print(subjects)

